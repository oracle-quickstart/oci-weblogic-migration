# Copyright (c) 2024 Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v1.0 as shown at https://oss.oracle.com/licenses/upl.

#resource "oci_core_network_security_group_security_rule" "bastion_ingress_security_rule" {
##  count = var.existing_bastion_instance_id == "" && var.is_bastion_instance_required && !var.assign_backend_public_ip ? 1 : 0
#  count = local.bastion_nsg_enabled
##  network_security_group_id = element(var.nsg_ids["bastion_nsg_id"], 0)
#  network_security_group_id = local.bastion_nsg_id
#  direction                 = "INGRESS"
#  protocol                  = "6"
#  description = ""
#
#  source      = "0.0.0.0/0"
#  source_type = "CIDR_BLOCK"
#  stateless   = false
#
#  tcp_options {
#    destination_port_range {
#      max = 22
#      min = 22
#    }
#  }
#}

#resource "oci_core_network_security_group" "bastion_ingress_security_rule" {
#  count          = local.bastion_nsg_enabled ? 1 : 0
##  count = var.existing_bastion_instance_id == "" && var.is_bastion_instance_required && !var.assign_backend_public_ip ? 1 : 0
#  compartment_id = var.compartment_id
#  display_name   = "bastion-${var.state_id}"
#  vcn_id         = var.vcn_id
#  defined_tags   = var.tags.defined_tags
#  freeform_tags  = var.tags.freeform_tags
#  lifecycle {
#    ignore_changes = [defined_tags, freeform_tags, display_name]
#  }
#}



locals {
  bastion_nsg_config = try(var.nsg_ids.bastion_nsg_id, { create = "never" })
#  bastion_nsg_create = coalesce(lookup(local.bastion_nsg_config, "create", null), "auto")
  bastion_nsg_enabled = var.existing_bastion_instance_id == "" && var.is_bastion_instance_required && !var.assign_backend_public_ip ? true : false
#  bastion_nsg_enabled = anytrue([
#    local.bastion_nsg_create == "always",
#    alltrue([
#      local.bastion_nsg_create == "auto",
#      coalesce(lookup(local.bastion_nsg_config, "id", null), "none") == "none",
#      var.create_bastion,
#    ]),
#  ])

  # Return provided NSG when configured with an existing ID or created resource ID
#  bastion_nsg_id = one(compact([try(var.nsg_ids.bastion_nsg_id.id, null), one(oci_core_network_security_group.bastion[*].id)])
   bastion_nsg_id = element(var.nsg_ids["bastion_nsg_id"], 0)
   bastion_rules = local.bastion_nsg_enabled ? merge(
        { for cidr in var.bastion_allowed_cidrs :
          "Allow SSH ingress to bastion from ${cidr}" => {
            protocol = local.tcp_protocol, port = local.ssh_port, source = cidr, source_type = local.rule_type_cidr,
          }
        },
        {
          "Allow TCP egress from bastion to OCI services" : {
            protocol = local.tcp_protocol, port = local.all_ports, destination = local.osn, destination_type = local.rule_type_service,
          },
        },
#        var.allow_worker_ssh_access && local.worker_nsg_enabled ? {
#          "Allow SSH egress from bastion to workers" = {
#            protocol = local.tcp_protocol, port = local.ssh_port, destination = local.worker_nsg_id, destination_type = local.rule_type_nsg,
#          },
#        } : {},
    ) : {}

  # Dynamic map of all NSG rules for enabled NSGs
  bastion_all_rules = { for x, y in merge(
    { for k, v in local.bastion_rules : k => merge(v, { "nsg_id" = local.bastion_nsg_id }) },
  ) : x => merge(y, {
    description               = x
    network_security_group_id = lookup(y, "nsg_id")
    direction                 = contains(keys(y), "source") ? "INGRESS" : "EGRESS"
    protocol                  = lookup(y, "protocol")
    source                    = lookup(y, "source", null)
    source_type               = lookup(y, "source_type", null)
    destination               = lookup(y, "destination", null)
    destination_type          = lookup(y, "destination_type", null)
  }) }
}

resource "oci_core_network_security_group_security_rule" "bastion_ingress_security_rule" {
  for_each                  = local.bastion_all_rules
  stateless                 = false
  description               = each.value.description
  destination               = each.value.destination
  destination_type          = each.value.destination_type
  direction                 = each.value.direction
  network_security_group_id = each.value.network_security_group_id
  protocol                  = each.value.protocol
  source                    = each.value.source
  source_type               = each.value.source_type

  dynamic "tcp_options" {
    for_each = (tostring(each.value.protocol) == tostring(local.tcp_protocol) &&
    tonumber(lookup(each.value, "port", 0)) != local.all_ports ? [each.value] : []
    )
    content {
      destination_port_range {
        min = tonumber(lookup(tcp_options.value, "port_min", lookup(tcp_options.value, "port", 0)))
        max = tonumber(lookup(tcp_options.value, "port_max", lookup(tcp_options.value, "port", 0)))
      }
    }
  }

  dynamic "udp_options" {
    for_each = (tostring(each.value.protocol) == tostring(local.udp_protocol) &&
    tonumber(lookup(each.value, "port", 0)) != local.all_ports ? [each.value] : []
    )
    content {
      destination_port_range {
        min = tonumber(lookup(udp_options.value, "port_min", lookup(udp_options.value, "port", 0)))
        max = tonumber(lookup(udp_options.value, "port_max", lookup(udp_options.value, "port", 0)))
      }
    }
  }

  dynamic "icmp_options" {
    for_each = tostring(each.value.protocol) == tostring(local.icmp_protocol) ? [1] : []
    content {
      type = 3
      code = 4
    }
  }

  lifecycle {
    precondition {
      condition = tostring(each.value.protocol) == tostring(local.icmp_protocol) || contains(keys(each.value), "port") || (
      contains(keys(each.value), "port_min") && contains(keys(each.value), "port_max")
      )
      error_message = "TCP/UDP rule must contain a port or port range: '${each.key}'"
    }

    precondition {
      condition = (
      tostring(each.value.protocol) == tostring(local.icmp_protocol)
      || can(tonumber(each.value.port))
      || (can(tonumber(each.value.port_min)) && can(tonumber(each.value.port_max)))
      )

      error_message = "TCP/UDP ports must be numeric: '${each.key}'"
    }

    precondition {
      condition     = each.value.direction == "EGRESS" || coalesce(each.value.source, "none") != "none"
      error_message = "Ingress rule must have a source: '${each.key}'"
    }

    precondition {
      condition     = each.value.direction == "INGRESS" || coalesce(each.value.destination, "none") != "none"
      error_message = "Egress rule must have a destination: '${each.key}'"
    }

    # Extra precaution against unexpected allow-all ingress rules created by the module
    # Generated rules will produce errors unless any of the follow conditions are true
    precondition {
      condition = anytrue([
        tostring(each.value.protocol) == tostring(local.icmp_protocol), # Traffic is ICMP
        each.value.direction == "EGRESS",                               # Traffic is outbound
        each.value.source != local.anywhere,                            # Rule does not allow all traffic

        # SSH ingress to bastion from anywhere has been configured explicitly
        alltrue([
          tonumber(lookup(each.value, "port", 0)) == local.ssh_port,
          contains(var.bastion_allowed_cidrs, local.anywhere),
        ]),

      ])
      error_message = "Unexpected open ingress rule: ${each.key}"
    }
  }
}

output "bastion_nsg_id" {
  value = local.bastion_nsg_id
}