# Copyright (c) 2024 Oracle Corporation and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl

variable "tenancy_ocid" {
  default = null
  type    = string
}

variable "current_user_ocid" {
  default = null
  type    = string
}

variable "compartment_ocid" {
  default = null
  type    = string
}

variable "region" {
  default = null
  type    = string
}

variable "api_fingerprint" {
  default = null
  type    = string
}

variable "create_iam_tag_namespace" { default = false }
variable "create_iam_defined_tags" { default = false }
variable "use_defined_tags" {
  default     = false
  description = "Add existing tags in the configured namespace to created resources when applicable."
  type        = bool
}

variable "tag_namespace" {
  default     = "wls"
  description = "Tag namespace containing standard tags for resources created by the module: [state_id, role, wlsservers]."
  type        = string
}

variable "freeform_tags" {
  default = {
    cluster           = {}
    persistent_volume = {}
    service_lb        = {}
    wlsservers           = {}
    bastion           = {}
    vcn               = {}
    resource_manager  = {}
  }
  type = any
}

variable "defined_tags" {
  default = {
    cluster           = {}
    persistent_volume = {}
    service_lb        = {}
    wlsservers           = {}
    bastion           = {}
    vcn               = {}
    resource_manager  = {}
  }
  type = any
}
