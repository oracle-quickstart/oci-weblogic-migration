# Copyright (c) 2024 Oracle Corporation and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl
# shellcheck disable=SC1091
# This is an auto-generated file.
update_any_ds=true
update_ds_0=true
ds_0="jdbc:oracle:thin:@(description=(retry_count=20)(retry_delay=3)(address=(protocol=tcps)(port=1522)(host=adb.us-ashburn-1.oraclecloud.com))(connect_data=(service_name=i7lmxzfldrf94l0_mbatp_low.adb.oraclecloud.com))(security=(ssl_server_dn_match=yes)))"
