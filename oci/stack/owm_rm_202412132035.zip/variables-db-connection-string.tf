# Copyright (c) 2024 Oracle Corporation and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl
# shellcheck disable=SC1091
# This is an auto-generated file.


variable "update_any_ds" {
  type = bool
  default = false
}

#/////////////////
# Datasource #0
#/////////////////
variable "ds_0" {
  type = string
  default = ""
}

variable "update_ds_0" {}

# ATP DB Configuration
# Variable used in UI only
variable "atp_db_uses_private_endpoint_0" {
  type        = bool
  description = "Indicates if the ATP database uses private endpoint for network access"
  default     = false
}

variable "atp_db_network_compartment_id_0" {
  type        = string
  description = "The OCID of the compartment in which the ATP database private endpoint VCN is found"
  default     = ""
}

variable "atp_db_existing_vcn_id_0" {
    type        = string
    description = "The OCID of the VCN used by the ATP database private endpoint"
    default     = ""
}

variable "atp_db_compartment_id_0" {
  type        = string
  description = "The OCID of the compartment where the ATP database is located"
  default     = ""
}
variable "atp_db_id_0" {
  type        = string
  description = "The OCID of the ATP database"
  default     = ""
}

variable "atp_db_level_0" {
  type        = string
  description = "The ATP database level. Allowed values are low, tp, tpurgent"
  default     = "low"
  validation {
    condition     = contains(["low", "tp", "tpurgent"], var.atp_db_level_0)
    error_message = "WLSC-ERROR: Invalid value for atp_db_level. Allowed values are low, tp and tpurgent."
  }
}

variable "db_strategy_0" {
  type=string
  default     = "Autonomous Transaction Processing Database"
  validation {
    condition     = contains(["Autonomous Transaction Processing Database", "Database System", "Edit JDBC String"], var.db_strategy_0)
    error_message = "Accepted values are Autonomous Transaction Processing Database, Database System, Edit JDBC String"
  }
}

variable "oci_db_connection_string_0" {
  type=string
  description = "Oracle database connection string to connect to database. Example: //<scan_hostname>.<host_domain_name>:<db_port>/<pdb_or_sid>.<Host Domain Name>"
  default = ""
}

##### OCI Database Service #########
variable "oci_db_port_0" {
  type        = number
  description = "The listener port for the OCI database"
  default     = 1521
}

variable "oci_db_compartment_id_0" {
  type        = string
  description = "The OCID of the compartment of the OCI database"
  default     = ""
}

variable "oci_db_network_compartment_id_0" {
  type        = string
  description = "The OCID of the compartment in which the DB System VCN is found"
  default     = ""
}

variable "oci_db_dbsystem_id_0" {
  type        = string
  description = "The OCID of the OCI database system"
  default     = ""
}

# Variable used in UI only
variable "oci_db_dbhome_id_0" {
  type        = string
  description = "The OCID of the OCI database home"
  default     = ""
}

# Variable used in UI only  # What is this used for?
variable "oci_db_dbhome_major_version_0" {
  type        = string
  description = "Version of Database home in the DB System"
  default     = ""
}

variable "oci_db_database_id_0" {
  type        = string
  description = "The OCID of the OCI database"
  default     = ""
}

variable "oci_db_pdb_service_name_0" {
  type        = string
  description = "The name of the pluggable database (PDB) in which to provision the schemas for a JRF-enabled WebLogic Server domain. This is required for Oracle Database 12c or later"
  default     = ""
}
#/////////////////
# End Section: Datasource #0
#/////////////////
